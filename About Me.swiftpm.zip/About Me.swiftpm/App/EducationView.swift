/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

struct EducationView: View {
    var body: some View {
        VStack {
            Text("Education")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 1)
            
            
            Image("Shaqralogo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(150)
                .padding()
                
            
            Text("Experiences")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            HStack(spacing: 60) {
                Image(systemName: "apple.logo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .foregroundColor(Color.gray)
                
                Image("android.logo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
            .padding()
            HStack(spacing: 60) {
                
                Text("Course:\niOS Development with Swift")
               
                Text("Course:\nAndroid Basics")
            }
            .padding()

        
        }
    }
}

struct EducationView_Previews: PreviewProvider {
    static var previews: some View {
        EducationView()
    }
}
