/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

struct AimsView: View {
    var body: some View {
        VStack {
            Text("My Aims")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            ScrollView {
                Text(information.aims)
                    .font(.title2)
                    .foregroundColor(Color("myColor"))
                    .padding()
            }
        }
        .padding([.top, .bottom], 50)
    }
}

struct AimsView_Previews: PreviewProvider {
    static var previews: some View {
        AimsView()
    }
}
