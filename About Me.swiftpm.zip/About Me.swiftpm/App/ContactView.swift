/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

struct ContactView: View {

    var body: some View {
        VStack {
            Text("Contact Me")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
                .position(x: 180,y: 120)
            
            
            Image(systemName: "envelope")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .position(x: 110,y: 0)
                .padding(70)
            
            Link("Feel free to send me an email", destination: URL(string: "https://Marwah.A.Thabit@gmail.com")!)
            
            Text("Marwah.A.Thabit@gmail.com")
                .padding()

        }
        .padding()
    }
}

struct ContactView_Previews: PreviewProvider {
    static var previews: some View {
        ContactView()
    }
}
