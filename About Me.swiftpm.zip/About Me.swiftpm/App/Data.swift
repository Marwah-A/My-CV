/*
See the License.txt file for this sample’s licensing information.
*/

import Foundation
import SwiftUI

struct Info {
    let image: String
    let name: String
    let aims: String
    let colors: [Color]

}

let information = Info(
    image: "cat",
    name: "Marwah Ameen Abdullah",
    aims: "• Understanding life and being happy at every stage in life.\n\n• Graduating with first-class honor.\n\n• Growing in mobile app development for iOS and Andriod.\n\n• Developing applications that serve the world and make life easier.\n\n• Creating a software engineering company.",
    colors: [Color.blue, Color.purple, Color.pink]
    
)
